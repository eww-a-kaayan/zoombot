# Zoombot
A highly advanced AI to handle all those Zoom calls so you can live your life in peace. WARNING: Everything about this project is shitty other than Artyom.js (which was actually coded by someone who knows what they're doing) so I take no responsibility for not preloading the images, not creating a local https server, and using some random old ass version of jQuery. Sorry for the nightmares but hey, this thing actually works so have fun! If you want to learn a little more about Zoombot I wrote this too https://redpepper.land/blog/zoombot/


## Setup
- Replace the images in /img with your pics
- Put all these files on a server running https:// otherwise Chrome throws security errors and can't access your microphone.
- Visit your Zoombot https:// URL in Chrome
- Turn on Zoombot with the button in the top left and it will start listening for all those key phrases
- Create a virtual webcam with Chrome as the source. I used ManyCam to do this.
- Set your Zoom camera to "ManyCam Virtual Webcam"
- Turn up your speakers
- Talk to your Zoombot <3


## Credits
Special thanks to Carlos Delgado for making Artyom.js which powers the listening and speaking parts of this project. He's good https://github.com/sdkcarlos/artyom.js/
